
package lab2;



import java.io.IOException;

import java.nio.charset.Charset;

import org.openqa.selenium.By;

import org.openqa.selenium.WebDriver;

import org.openqa.selenium.WebElement;

import org.openqa.selenium.firefox.*;

import com.csvreader.CsvReader;



public class Test {

   

public static void main(String[] args) throws IOException {

                            

       CsvReader r = new CsvReader("D://����ѧ//������������ѧ//��������//inputgit.csv", ',' , Charset.forName("GBK"));

       r.readHeaders();  //��ͷ��

       while (r.readRecord()) {                        

    	   r.readRecord();             

    	   String number_csv = r.get("ѧ��");              

    	   String name_csv = r.get("����");

    	   String address_csv = r.get("github��ַ");

    	   String pwd_csv = number_csv.substring(number_csv.length()-6,number_csv.length());

    	   //��ȡCSV�ļ�������

       

    	   System.setProperty("webdriver.firefox.bin", "C:/Program Files (x86)/Mozilla Firefox/firefox.exe"); 

    	   WebDriver driver = new FirefoxDriver();

    	   driver.get("http://103.120.226.190/selenium-demo/git-repo");               

    	   driver.manage().window().maximize();

    	   //ͨ��������������ַ

      

    	   WebElement input_name = driver.findElement(By.id("name"));

    	   WebElement input_pwd = driver.findElement(By.id("pwd"));

    	   WebElement btn = driver.findElement(By.id("submit"));

    	   input_name.clear();

    	   input_pwd.clear();

    	   input_name.sendKeys(number_csv);

    	   input_pwd.sendKeys(pwd_csv);  	   

    	   btn.click();

    	   //����CSV�ж���������

    	   

    	   String info = driver.findElement(By.xpath("//tbody[@id='table-main']")).getText();

    	   //ͨ��Xpath����λ�û���Ϣ��λ��

    	   String name = info.substring(info.indexOf("��") + 2, info.indexOf("ѧ") - 1);

    	   String number = info.substring(info.indexOf("��") + 2, info.indexOf("G") - 1);

    	   String address = info.substring(info.indexOf("ַ") + 2);  

    	   //��¼��ҳ�е���Ϣ

    	   

    	   String firstname = name.substring(0, 1);

    	   if(name_csv.equals(name)&&number_csv.equals(number)&&address_csv.equals(address))

               System.out.println(firstname+"ͬѧͨ��");

    	   else

               System.out.println(firstname+"ͬѧδͨ��");

    	   driver.close();

        }

        r.close();         

}  

}