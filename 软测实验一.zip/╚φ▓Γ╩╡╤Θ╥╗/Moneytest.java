package testmoney;

public class Moneytest {

}
