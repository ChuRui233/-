package money;

public class Money {

}
