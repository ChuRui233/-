import static org.junit.Assert*;

import org.junit.Assert;
import org.junit.Test;

public class BubbleSortTest {
	
	public void test() {
		BubbleSort bub = new BubbleSort;
		
		int arr[] = new int[]{1,6,2,2,5};
	int a[] = new int[](1,2,2,5,6};
	Assert.assrtArrayEquals(a, bub.BubbleSort(arr));
	
}

}